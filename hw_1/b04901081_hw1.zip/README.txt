[Overall]
    This is a chart-producing machine which catches data from https://ceiba.ntu.edu.tw/course/481ea4/hw1_data.csv.
    You're allowed to choose which class to be shown as categories, as well as which diagram/chart as presentation format.

[Code]
    # Function
        // Pre-process
            parse_to_list(data_str):
                parse the csv data into many children row lists stored in one parent list.
            data_parse(data_list):
                parse the list data into one dictionary to refine the following process.

        // Draw Charts
            group_barchart(data_dic, type):
                draw a barchart with the dictionary data based on the chosen class.
            group_lineplot(data_dic, type):
                draw a lineplot with the dictionary data based on the chosen class.
            piechart(data_dic, type) :
                draw a piechart with the dictionary data based on the chosen class.

    # Mainloop
        // Catch csv data through request
        // Parse the csv data perfectly by using those functions above
        // Read the command line and determine what charts should be drawn
        // Show the charts based on the argv (from command line)